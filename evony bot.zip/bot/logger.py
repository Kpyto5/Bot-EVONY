import tkinter as tk
from tkinter import scrolledtext
from datetime import datetime

class GUILogger:
    def __init__(self, log_widget):
        self.log_widget = log_widget
        self.log_widget.tag_config("success", foreground="#2ecc71")
        self.log_widget.tag_config("warn", foreground="#b22222")
        self.log_widget.tag_config("debug", foreground="#9b8f7a")
        self.log_widget.tag_config("error", foreground="#b22222")
        self.log_widget.tag_config("info", foreground="#e9e6df")

    def log(self, message, icon="ℹ️", level="INFO"):
        now = datetime.now().strftime("%H:%M:%S")
        tag = level.lower()
        line = f"[{now}] {icon} [{level}] {message}\n"
        self.log_widget.config(state="normal")
        self.log_widget.insert(tk.END, line, tag)
        self.log_widget.see(tk.END)
        self.log_widget.config(state="disabled")