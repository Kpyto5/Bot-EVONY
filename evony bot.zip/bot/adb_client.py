from ppadb.client import Client as AdbClient
import cv2
import numpy as np
from bot.constants import ADB_HOST, ADB_PORT
import time

class AdbWrapper:
    def __init__(self, host=ADB_HOST, port=ADB_PORT):
        self.host = host
        self.port = port
        self.client = None
        self.devices = []
        self.connect()

    def connect(self):
        try:
            self.client = AdbClient(host=self.host, port=self.port)
        except Exception as e:
            print(f"ADB connection error: {e}")
            self.client = None

    def refresh_devices(self):
        if not self.client:
            return ["ADB not connected"]
        try:
            self.devices = [d.serial for d in self.client.devices()]
            return self.devices if self.devices else ["No devices found"]
        except Exception as e:
            return [f"Error: {e}"]

    def get_device(self, serial):
        if not self.client:
            return None
        try:
            return self.client.device(serial)
        except:
            return None

    def screencap(self, device):
        return device.screencap()

    def screencap_to_img(self, device):
        raw = device.screencap()
        if raw:
            return cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
        return None

    def tap(self, device, x, y):
        device.shell(f"input tap {x} {y}")

    def swipe(self, device, x1, y1, x2, y2, duration_ms):
        device.shell(f"input touchscreen swipe {x1} {y1} {x2} {y2} {duration_ms}")

    def keyevent(self, device, key):
        device.shell(f"input keyevent {key}")

    # --------------------- Нові методи -------------------------
    def is_app_foreground(self, device, package):
        """
        Перевіряє, чи пакет зараз на передньому плані.
        Повертає True, якщо застосунок активний.
        """
        try:
            # Отримуємо поточну активність
            result = device.shell("dumpsys activity activities | grep mResumedActivity")
            return package in result
        except Exception as e:
            print(f"is_app_foreground error: {e}")
            return False

    def launch_app(self, device, package):
        """
        Запускає застосунок через monkey (якщо він не запущений).
        Можна також використати 'am start', але monkey надійніший для ігор.
        """
        try:
            device.shell(f"monkey -p {package} -c android.intent.category.LAUNCHER 1")
            time.sleep(2)  # чекаємо, поки гра завантажиться
            return True
        except Exception as e:
            print(f"launch_app error: {e}")
            return False