# bot/ui_components.py
import tkinter as tk
from tkinter import ttk, scrolledtext
from bot.constants import *
from bot.logger import GUILogger
from bot.wheel_spinner import WheelSpinner
from bot.training_spinner import TrainingSpinner
from bot.viking_bot import VikingBot

class UIBuilder:
    def __init__(self, root, bot_instance):
        self.root = root
        self.bot = bot_instance
        self.setup_styles()
        self.create_tabs()
        self.create_header()
        self.account_rows = {}
        self.create_account_rows()
        self.create_log_area()
        self.create_wheel_tab()
        self.create_training_tab()
        self.create_viking_tab()
        self.bot.set_logger(self.log_widget)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('default')
        style.configure('TNotebook', background=BG_COLOR)
        style.configure('TNotebook.Tab', background=PANEL_COLOR, foreground=GOLD_ACCENT, padding=[12,6])

    def create_tabs(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True)
        self.frame_control = tk.Frame(self.notebook, bg=PANEL_COLOR)
        self.frame_logs = tk.Frame(self.notebook, bg=LOG_BG)
        self.frame_wheel = tk.Frame(self.notebook, bg=PANEL_COLOR)
        self.frame_training = tk.Frame(self.notebook, bg=PANEL_COLOR)
        self.frame_viking = tk.Frame(self.notebook, bg=PANEL_COLOR)
        self.notebook.add(self.frame_control, text="   ПАНЕЛЬ КЕРУВАННЯ АКАУНТАМИ   ")
        self.notebook.add(self.frame_logs, text="   СИСТЕМНИЙ ЖУРНАЛ (LOGS)   ")
        self.notebook.add(self.frame_wheel, text="   КОЛЕСО ФОРТУНИ   ")
        self.notebook.add(self.frame_training, text="   ТРЕНУВАННЯ ВІЙСЬК   ")
        self.notebook.add(self.frame_viking, text="   ⚔ ВІКІНГИ   ")

    def create_header(self):
        header = tk.Frame(self.frame_control, bg=HEADER_COLOR, height=48)
        header.pack(fill="x", padx=6, pady=6)
        lbl_cfg = {"fg": GOLD_ACCENT, "bg": HEADER_COLOR, "font": ("Arial", 9, "bold")}
        tk.Label(header, text="АККАУНТ", width=14, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="МАРШІ", width=8, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="ПРИСТРІЙ (ADB SERIAL)", width=25, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="РЕЖИМ", width=14, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="ФІЛЬТРИ", width=14, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="МІН. POWER", width=12, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="ДІЇ", width=22, **lbl_cfg).pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="LED", width=8, **lbl_cfg).pack(side=tk.LEFT, padx=2)

        btn_refresh = tk.Button(
            header,
            text="Refresh ADB",
            bg=BUTTON_SECONDARY,
            fg=TEXT_LIGHT,
            activebackground=BUTTON_PRIMARY,
            relief=tk.FLAT,
            command=lambda: self.bot.refresh_devices_async()
        )
        btn_refresh.pack(side=tk.RIGHT, padx=8, pady=6)

        btn_power_refresh = tk.Button(
            header,
            text="Power Refresh",
            bg=BUTTON_PRIMARY,
            fg=TEXT_LIGHT,
            activebackground=BUTTON_PRIMARY_HOVER,
            relief=tk.FLAT,
            command=lambda: self.bot.refresh_power_templates_async()
        )
        btn_power_refresh.pack(side=tk.RIGHT, padx=8, pady=6)

    def create_account_rows(self):
        for i in range(1, 6):
            self.create_account_row(f"Account {i}")

    def create_account_row(self, name):
        frame = tk.Frame(self.frame_control, bg=PANEL_COLOR, highlightthickness=1, highlightbackground="#2a1f12")
        frame.pack(fill="x", padx=6, pady=4)

        # 1. Ім'я
        tk.Label(frame, text=name, fg=TEXT_LIGHT, bg=PANEL_COLOR, width=14, anchor="w", padx=10, font=("Arial",10,"bold")).pack(side=tk.LEFT)

        # 2. Статистика
        self.bot.gui_vars["stats"][name] = tk.IntVar(value=0)
        tk.Label(frame, textvariable=self.bot.gui_vars["stats"][name], fg=GREEN_OK, bg=PANEL_COLOR, width=8, font=("Consolas",10,"bold")).pack(side=tk.LEFT)

        # 3. Вибір пристрою
        self.bot.gui_vars["serials"][name] = tk.StringVar()
        device_choices = self.bot.device_list if self.bot.device_list else ["None"]
        dropdown = tk.OptionMenu(frame, self.bot.gui_vars["serials"][name], *device_choices)
        dropdown.config(width=22, bg=BUTTON_PRIMARY, fg=TEXT_LIGHT, highlightthickness=0, relief=tk.FLAT)
        dropdown["menu"].config(bg=PANEL_COLOR, fg=TEXT_LIGHT)
        dropdown.pack(side=tk.LEFT, padx=6)
        self.bot.dropdown_map[name] = {"widget": dropdown, "menu": dropdown["menu"]}

        # 4. Режим (P1 / M)
        radio_group = tk.Frame(frame, bg=PANEL_COLOR)
        radio_group.pack(side=tk.LEFT, padx=6)
        self.bot.gui_vars["modes"][name] = tk.StringVar(value="M")
        tk.Radiobutton(radio_group, text="P1", variable=self.bot.gui_vars["modes"][name], value="P1", bg=PANEL_COLOR, fg=TEXT_LIGHT, selectcolor=HEADER_COLOR).pack(side=tk.LEFT)
        tk.Radiobutton(radio_group, text="M", variable=self.bot.gui_vars["modes"][name], value="M", bg=PANEL_COLOR, fg=TEXT_LIGHT, selectcolor=HEADER_COLOR).pack(side=tk.LEFT)

        # 5. Фільтр BOSS
        self.bot.gui_vars["filters"][name] = tk.StringVar(value="OFF")
        btn_filter = tk.Button(
            frame,
            textvariable=self.bot.gui_vars["filters"][name],
            width=12,
            bg=CRIMSON,
            fg=TEXT_LIGHT,
            font=("Arial",8,"bold"),
            relief=tk.FLAT,
            command=lambda nm=name: self.bot.toggle_filter(nm)
        )
        btn_filter.pack(side=tk.LEFT, padx=6)
        self.bot.filter_buttons_map[name] = btn_filter

        # 6. Мінімальна потужність для OCR-фільтра
        self.bot.gui_vars["min_power"][name] = tk.StringVar(value="0M")
        entry_min_power = tk.Entry(
            frame,
            textvariable=self.bot.gui_vars["min_power"][name],
            width=12,
            bg="#2a2a2a",
            fg=TEXT_LIGHT,
            insertbackground=TEXT_LIGHT,
            relief=tk.FLAT,
            font=("Arial",8)
        )
        entry_min_power.pack(side=tk.LEFT, padx=6)

        # 7. START/STOP
        action_group = tk.Frame(frame, bg=PANEL_COLOR)
        action_group.pack(side=tk.LEFT, padx=6)
        tk.Button(action_group, text="START", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT, width=9, relief=tk.FLAT,
                  command=lambda nm=name: self.bot.start_account(nm)).pack(side=tk.LEFT, padx=3)
        tk.Button(action_group, text="STOP", bg=CRIMSON, fg=TEXT_LIGHT, width=9, relief=tk.FLAT,
                  command=lambda nm=name: self.bot.stop_account(nm)).pack(side=tk.LEFT, padx=3)

        # 8. LED індикатор
        led = tk.Canvas(frame, width=18, height=18, bg="#333333", highlightthickness=0)
        led.pack(side=tk.LEFT, padx=18)
        self.bot.status_leds_map[name] = led

    def create_log_area(self):
        self.log_widget = scrolledtext.ScrolledText(self.frame_logs, bg=LOG_BG, fg=LOG_FG, font=("Consolas",10))
        self.log_widget.pack(fill="both", expand=True, padx=6, pady=6)

    # --- Вкладка КОЛЕСО ФОРТУНИ ---
    def create_wheel_tab(self):
        stats_frame = tk.LabelFrame(self.frame_wheel, text="Статистика", padx=10, pady=5, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        stats_frame.pack(pady=5, fill="x", padx=10)

        self.wheel_counter_var = tk.IntVar(value=self.bot.wheel_spinner.get_counter() if self.bot.wheel_spinner else 0)
        tk.Label(stats_frame, text="Всього прокруток:", bg=PANEL_COLOR, fg=TEXT_LIGHT).pack(side="left")
        self.wheel_counter_label = tk.Label(stats_frame, textvariable=self.wheel_counter_var, font=("Arial", 12, "bold"), fg=GREEN_OK, bg=PANEL_COLOR)
        self.wheel_counter_label.pack(side="left", padx=10)
        tk.Button(stats_frame, text="Скинути", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
                  command=self.reset_wheel_counter).pack(side="right")

        delay_frame = tk.LabelFrame(self.frame_wheel, text="Налаштування затримки (сек)", padx=10, pady=10, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        delay_frame.pack(pady=5, fill="x", padx=10)
        self.wheel_delay_var = tk.DoubleVar(value=1.5)
        tk.Scale(delay_frame, from_=0.5, to=5.0, resolution=0.1, orient="horizontal",
                 variable=self.wheel_delay_var, bg=PANEL_COLOR, fg=TEXT_LIGHT,
                 command=lambda x: self.update_wheel_delay()).pack(fill="x")

        dev_frame = tk.LabelFrame(self.frame_wheel, text="Емулятор / Пристрій", padx=10, pady=5, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        dev_frame.pack(pady=5, fill="x", padx=10)
        self.wheel_device_var = tk.StringVar()
        device_choices = self.bot.device_list if self.bot.device_list else ["None"]
        self.wheel_device_dropdown = ttk.Combobox(dev_frame, textvariable=self.wheel_device_var, values=device_choices, state="readonly")
        self.wheel_device_dropdown.pack(pady=5, fill="x")
        if device_choices and device_choices[0] != "None":
            self.wheel_device_dropdown.current(0)
            self.wheel_device_var.set(device_choices[0])
        btn_refresh = tk.Button(dev_frame, text="Оновити список", bg=BUTTON_SECONDARY, fg=TEXT_LIGHT,
                                command=lambda: self.bot.refresh_devices_async())
        btn_refresh.pack(pady=5)

        mode_frame = tk.LabelFrame(self.frame_wheel, text="Вибір режиму", padx=10, pady=5, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        mode_frame.pack(pady=5, fill="x", padx=10)
        self.wheel_mode_var = tk.StringVar(value="spin_100")
        for text, mode in [("100 Вращений", "spin_100"), ("10 Вращений", "spin_10"), ("1 Вращение", "spin_1")]:
            tk.Radiobutton(mode_frame, text=text, variable=self.wheel_mode_var, value=mode,
                           bg=PANEL_COLOR, fg=TEXT_LIGHT, selectcolor=HEADER_COLOR).pack(anchor="w")

        self.wheel_start_btn = tk.Button(self.frame_wheel, text="ЗАПУСТИТИ", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
                                         font=("Arial", 14, "bold"), height=2, command=self.toggle_wheel)
        self.wheel_start_btn.pack(pady=10, fill="x", padx=10)

        self.bot.wheel_ui = self

    def reset_wheel_counter(self):
        if self.bot.wheel_spinner:
            self.bot.wheel_spinner.set_counter(0)
            self.wheel_counter_var.set(0)
            self.bot.add_log_entry("Лічильник колеса скинуто.", "🔄", "INFO")

    def update_wheel_delay(self):
        if self.bot.wheel_spinner:
            self.bot.wheel_spinner.set_delay(self.wheel_delay_var.get())

    def toggle_wheel(self):
        if not self.bot.wheel_spinner:
            self.bot.wheel_spinner = WheelSpinner(self.bot.adb, self.bot.vision, self.bot.add_log_entry)
        if not self.bot.wheel_spinner.is_running:
            device = self.wheel_device_var.get()
            if not device or device == "None":
                self.bot.add_log_entry("Оберіть пристрій для колеса!", "❌", "ERROR")
                return
            self.bot.wheel_spinner.set_device(device)
            self.bot.wheel_spinner.set_mode(self.wheel_mode_var.get())
            self.bot.wheel_spinner.set_delay(self.wheel_delay_var.get())
            if self.bot.wheel_spinner.start():
                self.wheel_start_btn.config(text="ЗУПИНИТИ", bg=CRIMSON)
                self._poll_wheel_counter()
        else:
            self.bot.wheel_spinner.stop()
            self.wheel_start_btn.config(text="ЗАПУСТИТИ", bg=BUTTON_PRIMARY)

    def _poll_wheel_counter(self):
        if self.bot.wheel_spinner and self.bot.wheel_spinner.is_running:
            self.wheel_counter_var.set(self.bot.wheel_spinner.get_counter())
            self.root.after(1000, self._poll_wheel_counter)

    # --- Вкладка ТРЕНУВАННЯ ВІЙСЬК ---
    def create_training_tab(self):
        stats_frame = tk.LabelFrame(self.frame_training, text="Статистика", padx=10, pady=5, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        stats_frame.pack(pady=5, fill="x", padx=10)

        self.training_cycles_var = tk.IntVar(value=self.bot.training_spinner.get_cycles() if self.bot.training_spinner else 0)
        tk.Label(stats_frame, text="Виконано циклів:", bg=PANEL_COLOR, fg=TEXT_LIGHT).pack(side="left")
        self.training_cycles_label = tk.Label(stats_frame, textvariable=self.training_cycles_var, font=("Arial", 12, "bold"), fg=GREEN_OK, bg=PANEL_COLOR)
        self.training_cycles_label.pack(side="left", padx=10)
        tk.Button(stats_frame, text="Скинути", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
                  command=self.reset_training_cycles).pack(side="right")

        cycles_frame = tk.LabelFrame(self.frame_training, text="Кількість циклів (0 = безкінечно)", padx=10, pady=10, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        cycles_frame.pack(pady=5, fill="x", padx=10)
        self.training_cycles_target_var = tk.IntVar(value=0)
        tk.Spinbox(cycles_frame, from_=0, to=999, width=10, textvariable=self.training_cycles_target_var,
                   bg=BUTTON_PRIMARY, fg=TEXT_LIGHT, buttonbackground=BUTTON_SECONDARY).pack(pady=5)

        delay_frame = tk.LabelFrame(self.frame_training, text="Затримка між циклами (сек)", padx=10, pady=10, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        delay_frame.pack(pady=5, fill="x", padx=10)
        self.training_delay_var = tk.DoubleVar(value=2.0)
        tk.Scale(delay_frame, from_=0.5, to=10.0, resolution=0.1, orient="horizontal",
                 variable=self.training_delay_var, bg=PANEL_COLOR, fg=TEXT_LIGHT,
                 command=lambda x: self.update_training_delay()).pack(fill="x")

        dev_frame = tk.LabelFrame(self.frame_training, text="Емулятор / Пристрій", padx=10, pady=5, bg=PANEL_COLOR, fg=TEXT_LIGHT)
        dev_frame.pack(pady=5, fill="x", padx=10)
        self.training_device_var = tk.StringVar()
        device_choices = self.bot.device_list if self.bot.device_list else ["None"]
        self.training_device_dropdown = ttk.Combobox(dev_frame, textvariable=self.training_device_var, values=device_choices, state="readonly")
        self.training_device_dropdown.pack(pady=5, fill="x")
        if device_choices and device_choices[0] != "None":
            self.training_device_dropdown.current(0)
            self.training_device_var.set(device_choices[0])
        btn_refresh = tk.Button(dev_frame, text="Оновити список", bg=BUTTON_SECONDARY, fg=TEXT_LIGHT,
                                command=lambda: self.bot.refresh_devices_async())
        btn_refresh.pack(pady=5)

        self.training_start_btn = tk.Button(self.frame_training, text="ЗАПУСТИТИ", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
                                            font=("Arial", 14, "bold"), height=2, command=self.toggle_training)
        self.training_start_btn.pack(pady=10, fill="x", padx=10)

        self.bot.training_ui = self

    def reset_training_cycles(self):
        if self.bot.training_spinner:
            self.bot.training_spinner.reset_cycles()
            self.training_cycles_var.set(0)
            self.bot.add_log_entry("Лічильник тренувань скинуто.", "🔄", "INFO")

    def update_training_delay(self):
        if self.bot.training_spinner:
            self.bot.training_spinner.set_delay(self.training_delay_var.get())

    def toggle_training(self):
        if not self.bot.training_spinner:
            self.bot.training_spinner = TrainingSpinner(self.bot.adb, self.bot.vision, self.bot.add_log_entry)
        if not self.bot.training_spinner.is_running:
            device = self.training_device_var.get()
            if not device or device == "None":
                self.bot.add_log_entry("Оберіть пристрій для тренувань!", "❌", "ERROR")
                return
            self.bot.training_spinner.set_device(device)
            self.bot.training_spinner.set_target_cycles(self.training_cycles_target_var.get())
            self.bot.training_spinner.set_delay(self.training_delay_var.get())
            if self.bot.training_spinner.start():
                self.training_start_btn.config(text="ЗУПИНИТИ", bg=CRIMSON)
                self._poll_training_cycles()
        else:
            self.bot.training_spinner.stop()
            self.training_start_btn.config(text="ЗАПУСТИТИ", bg=BUTTON_PRIMARY)

    def _poll_training_cycles(self):
        if self.bot.training_spinner and self.bot.training_spinner.is_running:
            self.training_cycles_var.set(self.bot.training_spinner.get_cycles())
            self.root.after(1000, self._poll_training_cycles)

    # ═══════════════════════════════════════════════════════════════
    #  ВКЛАДКА: ⚔ ВІКІНГИ
    # ═══════════════════════════════════════════════════════════════
    def create_viking_tab(self):
        # Ініціалізуємо VikingBot у bot_instance якщо ще не створено
        if not hasattr(self.bot, 'viking_bot') or self.bot.viking_bot is None:
            self.bot.viking_bot = VikingBot(self.bot.adb, self.bot.add_log_entry)

        # ── Статистика циклів ──────────────────────────────────────
        stats_frame = tk.LabelFrame(
            self.frame_viking, text="Статистика", padx=10, pady=5,
            bg=PANEL_COLOR, fg=GOLD_ACCENT
        )
        stats_frame.pack(pady=5, fill="x", padx=10)

        self.viking_cycles_var = tk.IntVar(value=0)
        tk.Label(stats_frame, text="Успішних циклів:", bg=PANEL_COLOR, fg=TEXT_LIGHT).pack(side="left")
        tk.Label(stats_frame, textvariable=self.viking_cycles_var,
                 font=("Consolas", 12, "bold"), fg=GREEN_OK, bg=PANEL_COLOR).pack(side="left", padx=10)
        tk.Button(stats_frame, text="Скинути", bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
                  relief=tk.FLAT,
                  command=self._viking_reset_cycles).pack(side="right")

        # ── Пристрій ──────────────────────────────────────────────
        dev_frame = tk.LabelFrame(
            self.frame_viking, text="Емулятор / Пристрій (ADB)", padx=10, pady=5,
            bg=PANEL_COLOR, fg=GOLD_ACCENT
        )
        dev_frame.pack(pady=5, fill="x", padx=10)

        self.viking_device_var = tk.StringVar()
        device_choices = self.bot.device_list if self.bot.device_list else ["None"]
        self.viking_device_dropdown = ttk.Combobox(
            dev_frame, textvariable=self.viking_device_var,
            values=device_choices, state="readonly"
        )
        self.viking_device_dropdown.pack(pady=5, fill="x")
        if device_choices and device_choices[0] != "None":
            self.viking_device_dropdown.current(0)
            self.viking_device_var.set(device_choices[0])

        tk.Button(dev_frame, text="Оновити список", bg=BUTTON_SECONDARY, fg=TEXT_LIGHT,
                  relief=tk.FLAT,
                  command=self.bot.refresh_devices_async).pack(pady=5)

        # ── Затримка відпочинку ────────────────────────────────────
        delay_frame = tk.LabelFrame(
            self.frame_viking, text="Затримка між циклами (відпочинок після маршу, сек)",
            padx=10, pady=10, bg=PANEL_COLOR, fg=GOLD_ACCENT
        )
        delay_frame.pack(pady=5, fill="x", padx=10)

        self.viking_delay_var = tk.DoubleVar(value=15)
        self.viking_delay_label = tk.Label(
            delay_frame, text="15 сек",
            font=("Consolas", 13, "bold"), fg=GOLD_ACCENT, bg=PANEL_COLOR
        )
        self.viking_delay_label.pack()

        tk.Scale(
            delay_frame, from_=1, to=60, resolution=1, orient="horizontal",
            variable=self.viking_delay_var,
            bg=PANEL_COLOR, fg=TEXT_LIGHT, troughcolor=HEADER_COLOR,
            highlightthickness=0,
            command=self._viking_update_delay_label
        ).pack(fill="x")

        # ── Перевірка шаблонів ────────────────────────────────────
        tpl_frame = tk.LabelFrame(
            self.frame_viking,
            text="Шаблони (templates/viking/)",
            padx=10, pady=5, bg=PANEL_COLOR, fg=GOLD_ACCENT
        )
        tpl_frame.pack(pady=5, fill="x", padx=10)

        self.viking_tpl_status_frame = tk.Frame(tpl_frame, bg=PANEL_COLOR)
        self.viking_tpl_status_frame.pack(fill="x")
        self._viking_refresh_template_status()

        tk.Button(tpl_frame, text="🔄 Перевірити шаблони", bg=BUTTON_SECONDARY, fg=TEXT_LIGHT,
                  relief=tk.FLAT,
                  command=self._viking_refresh_template_status).pack(pady=4)

        # ── Кнопка СТАРТ / СТОП ───────────────────────────────────
        self.viking_start_btn = tk.Button(
            self.frame_viking,
            text="⚔  ЗАПУСТИТИ ВІКІНГІВ",
            bg=BUTTON_PRIMARY, fg=TEXT_LIGHT,
            font=("Arial", 14, "bold"), height=2,
            relief=tk.FLAT,
            command=self.toggle_viking
        )
        self.viking_start_btn.pack(pady=10, fill="x", padx=10)

    # ── Допоміжні методи вкладки ──────────────────────────────────
    def _viking_update_delay_label(self, value):
        self.viking_delay_label.config(text=f"{int(float(value))} сек")

    def _viking_reset_cycles(self):
        if hasattr(self.bot, 'viking_bot') and self.bot.viking_bot:
            self.bot.viking_bot.reset_cycles()
            self.viking_cycles_var.set(0)
            self.bot.add_log_entry("Лічильник вікінгів скинуто.", "🔄", "INFO")

    def _viking_refresh_template_status(self):
        # Очищаємо попередні мітки
        for w in self.viking_tpl_status_frame.winfo_children():
            w.destroy()

        statuses = self.bot.viking_bot.get_template_status()
        cols = 3
        for i, (fname, exists) in enumerate(statuses):
            color  = GREEN_OK if exists else CRIMSON
            symbol = "✔" if exists else "✘"
            tk.Label(
                self.viking_tpl_status_frame,
                text=f"{symbol} {fname}",
                fg=color, bg=PANEL_COLOR,
                font=("Consolas", 9),
                width=20, anchor="w"
            ).grid(row=i // cols, column=i % cols, padx=4, pady=1)

    def toggle_viking(self):
        vbot = self.bot.viking_bot
        if not vbot.is_running:
            device = self.viking_device_var.get()
            if not device or device in ("None", ""):
                self.bot.add_log_entry("Оберіть пристрій для вікінгів!", "❌", "ERROR")
                return
            vbot.set_device(device)
            vbot.set_rest_delay(self.viking_delay_var.get())
            if vbot.start():
                self.viking_start_btn.config(text="🛑  ЗУПИНИТИ ВІКІНГІВ", bg=CRIMSON)
                self._poll_viking_cycles()
        else:
            vbot.stop()
            self.viking_start_btn.config(text="⚔  ЗАПУСТИТИ ВІКІНГІВ", bg=BUTTON_PRIMARY)

    def _poll_viking_cycles(self):
        vbot = self.bot.viking_bot
        if vbot and vbot.is_running:
            self.viking_cycles_var.set(vbot.get_cycles())
            self.root.after(1000, self._poll_viking_cycles)
        else:
            # Бот зупинився — оновлюємо кнопку
            self.viking_start_btn.config(text="⚔  ЗАПУСТИТИ ВІКІНГІВ", bg=BUTTON_PRIMARY)
            if vbot:
                self.viking_cycles_var.set(vbot.get_cycles())
