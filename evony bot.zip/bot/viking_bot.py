# bot/viking_bot.py
import time
import threading
import os
import cv2
import numpy as np
import random
from bot.constants import BASE_DIR, EVONY_PACKAGE

DIR_VIKING_TEMPLATES = os.path.join(BASE_DIR, "templates", "viking")

VIKING_STEPS = [
    ("call",    "Призвать",                  15),
    ("viking",  "Вікінг на карті",           15),
    ("attack1", "Атака (меню)",              15),
    ("attack2", "Атака (підтвердження)",     15),
    ("preset1", "Пресет 1",                  10),
    ("march",   "МАРШ",                      10),
]

TEMPLATE_FILES = {
    "call":    "call.png",
    "viking":  "viking.png",
    "attack1": "attack1.png",
    "attack2": "attack2.png",
    "preset1": "preset1.png",
    "march":   "march.png",
}


class VikingBot:
    def __init__(self, adb_wrapper, logger_callback):
        self.adb        = adb_wrapper
        self.logger     = logger_callback
        self.device_serial = None
        self.is_running    = False
        self.rest_delay    = 15
        self.match_threshold = 0.75
        self.cycles = 0

    def set_device(self, serial: str):
        self.device_serial = serial

    def set_rest_delay(self, value: float):
        self.rest_delay = int(value)

    def get_cycles(self) -> int:
        return self.cycles

    def reset_cycles(self):
        self.cycles = 0

    def start(self) -> bool:
        if not self.device_serial:
            self.logger("Вікінги: пристрій не вибрано!", "❌", "ERROR")
            return False
        if self.is_running:
            return False
        self.is_running = True
        threading.Thread(target=self._loop, daemon=True).start()
        return True

    def stop(self):
        self.is_running = False

    def _ensure_game(self, device):
        if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
            self.logger("Гра неактивна. Спроба запуску...", "⚠️", "WARN")
            self.adb.launch_app(device, EVONY_PACKAGE)
            time.sleep(10)
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                self.logger("Не вдалося запустити Evony!", "☢️", "ERROR")
                return False
            self.logger("Гру повернено на передній план.", "✅", "SUCCESS")
        return True

    def _loop(self):
        self.logger("=== СТАРТ ВІКІНГ-БОТА ===", "⚔️", "INFO")

        device = self.adb.get_device(self.device_serial)
        if not device:
            self.logger(f"Не вдалося підключитись до {self.device_serial}", "❌", "ERROR")
            self.is_running = False
            return

        if not self._ensure_game(device):
            self.is_running = False
            return

        self.logger("Очікування 10 сек (повернення військ)…", "⏳", "INFO")
        for i in range(10, 0, -1):
            if not self.is_running:
                break
            self.logger(f"Початок через {i}…", "⏱️", "DEBUG")
            time.sleep(1)

        self.logger(">>> СТАРТ ЦИКЛУ АТАКИ <<<", "🗡️", "INFO")

        while self.is_running:
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                if not self._ensure_game(device):
                    break

            success = True

            for key, label, timeout in VIKING_STEPS:
                if not self.is_running:
                    break
                found = self._find_and_click(device, key, label, timeout)
                if not found:
                    self.logger(f"Не знайдено '{label}' за {timeout} сек — перезапуск циклу.", "⚠️", "WARN")
                    success = False
                    break
                time.sleep(2.0)

            if not self.is_running:
                break

            if success:
                self.cycles += 1
                self.logger(f"✅ Цикл #{self.cycles} завершено! Відпочинок {self.rest_delay} сек…", "🔄", "SUCCESS")
                for i in range(self.rest_delay, 0, -1):
                    if not self.is_running:
                        break
                    time.sleep(1)
            else:
                self.logger("Перезапуск через 3 сек…", "🔄", "WARN")
                time.sleep(3)

        self.is_running = False
        self.logger("=== ЗУПИНКА ВІКІНГ-БОТА ===", "🛑", "INFO")

    def _find_and_click(self, device, key: str, label: str, timeout: int) -> bool:
        tpl_name = TEMPLATE_FILES.get(key)
        if not tpl_name:
            self.logger(f"Невідомий ключ шаблону: {key}", "❌", "ERROR")
            return False

        tpl_path = os.path.join(DIR_VIKING_TEMPLATES, tpl_name)
        if not os.path.exists(tpl_path):
            self.logger(f"Шаблон не знайдено: {tpl_path}", "❌", "ERROR")
            return False

        template = cv2.imread(tpl_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            self.logger(f"Не вдалося завантажити шаблон: {tpl_path}", "❌", "ERROR")
            return False

        th, tw = template.shape[:2]
        deadline = time.time() + timeout

        while time.time() < deadline:
            if not self.is_running:
                return False

            # Перевіряємо гру всередині очікувань
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                self.logger("Гра зникла під час пошуку кнопки.", "⚠️", "WARN")
                return False

            screen = self.adb.screencap_to_img(device)
            if screen is None:
                time.sleep(1)
                continue

            screen_gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)

            try:
                res = cv2.matchTemplate(screen_gray, template, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, max_loc = cv2.minMaxLoc(res)
            except Exception as e:
                self.logger(f"Помилка matchTemplate ({label}): {e}", "❌", "ERROR")
                time.sleep(1)
                continue

            self.logger(f"Пошук '{label}': score={max_val:.3f}", "🔍", "DEBUG")

            if max_val >= self.match_threshold:
                cx = max_loc[0] + tw // 2 + random.randint(-3, 3)
                cy = max_loc[1] + th // 2 + random.randint(-3, 3)
                self.adb.tap(device, cx, cy)
                self.logger(f"✅ '{label}' знайдено та натиснуто (score={max_val:.3f})", "🔘", "INFO")
                return True

            time.sleep(1.2)

        return False

    def get_template_status(self) -> list:
        result = []
        for key, fname in TEMPLATE_FILES.items():
            path = os.path.join(DIR_VIKING_TEMPLATES, fname)
            result.append((fname, os.path.exists(path)))
        return result