# bot/march_logger.py
import json
import os
import time
from datetime import datetime, timedelta
from collections import defaultdict
from bot.constants import BASE_DIR

MARCH_LOG_FILE = os.path.join(BASE_DIR, "march_events.json")

class MarchLogger:
    def __init__(self):
        self.events = []            # список {"time": "ISO", "account": "..."}
        self._load()

    def _load(self):
        if os.path.exists(MARCH_LOG_FILE):
            try:
                with open(MARCH_LOG_FILE, "r", encoding="utf-8") as f:
                    self.events = json.load(f)
            except Exception:
                self.events = []

    def _save(self):
        with open(MARCH_LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(self.events, f, indent=2, ensure_ascii=False)

    def log_march(self, account_name):
        """Зафіксувати одне успішне приєднання до ралі."""
        event = {
            "time": datetime.now().isoformat(),
            "account": account_name
        }
        self.events.append(event)
        self._save()

    def get_hourly_counts(self, days=7):
        """
        Повертає словник {година (0-23): кількість} за останні N днів.
        """
        cutoff = datetime.now() - timedelta(days=days)
        counts = defaultdict(int)
        for ev in self.events:
            try:
                dt = datetime.fromisoformat(ev["time"])
                if dt >= cutoff:
                    counts[dt.hour] += 1
            except Exception:
                continue
        return dict(sorted(counts.items()))

    def get_daily_hourly_matrix(self, days=7):
        """
        Повертає матрицю 'день' x 'година' для теплової карти.
        Формат: { "YYYY-MM-DD": [count_h0, count_h1, ..., count_h23] }
        """
        cutoff = datetime.now() - timedelta(days=days)
        matrix = defaultdict(lambda: [0]*24)
        for ev in self.events:
            try:
                dt = datetime.fromisoformat(ev["time"])
                if dt >= cutoff:
                    day_key = dt.strftime("%Y-%m-%d")
                    matrix[day_key][dt.hour] += 1
            except Exception:
                continue
        return dict(sorted(matrix.items()))