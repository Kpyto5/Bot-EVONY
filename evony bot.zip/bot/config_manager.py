import json
import os
from bot.constants import CONFIG_FILE   # змінено імпорт

class ConfigManager:
    def __init__(self, config_file=CONFIG_FILE):
        self.config_file = config_file

    def load(self, account_names):
        if not os.path.exists(self.config_file):
            return {}
        try:
            with open(self.config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {}

    def save(self, account_data):
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(account_data, f, indent=4)