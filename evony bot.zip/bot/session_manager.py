# session_manager.py
import os
import json
import time
from datetime import datetime
import cv2
from bot.constants import DIR_SESSIONS, SESSIONS_INDEX, DETAILED_LOGGING, SAVE_ROI_IMAGES, LOG_CANDIDATES_CSV   # змінено імпорт

class SessionManager:
    def __init__(self, base_dir=DIR_SESSIONS, index_file=SESSIONS_INDEX):
        self.base_dir = base_dir
        self.index_file = index_file
        self.session_id = None
        self.session_path = None
        self.candidates_file = None
        self.events_file = None
        self.start_new_session()

    def start_new_session(self):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_id = f"session_{ts}"
        self.session_path = os.path.join(self.base_dir, self.session_id)
        os.makedirs(self.session_path, exist_ok=True)
        self.candidates_file = os.path.join(self.session_path, "candidates.csv")
        self.events_file = os.path.join(self.session_path, "events.jsonl")
        self._init_csv()
        self._register_in_index()

    def _init_csv(self):
        if LOG_CANDIDATES_CSV and not os.path.exists(self.candidates_file):
            with open(self.candidates_file, "w", encoding="utf-8") as f:
                f.write("timestamp,account,template,score,density,match_x,match_y,context\n")

    def _register_in_index(self):
        index = []
        if os.path.exists(self.index_file):
            with open(self.index_file, "r", encoding="utf-8") as f:
                try:
                    index = json.load(f)
                except:
                    index = []
        index.append({
            "session_id": self.session_id,
            "path": self.session_path,
            "start_time": datetime.now().isoformat(),
            "notes": ""
        })
        with open(self.index_file, "w", encoding="utf-8") as f:
            json.dump(index, f, indent=2)

    def append_event(self, event_dict):
        if not DETAILED_LOGGING:
            return
        with open(self.events_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(event_dict, ensure_ascii=False) + "\n")

    def log_candidate(self, account, tpl_name, score, density, match_x, match_y, context=""):
        if not (DETAILED_LOGGING and LOG_CANDIDATES_CSV):
            return
        with open(self.candidates_file, "a", encoding="utf-8") as f:
            f.write(f"{time.time()},{account},{tpl_name},{score:.4f},{density:.4f},{match_x},{match_y},{context}\n")

    def save_image(self, img, prefix):
        if not (DETAILED_LOGGING and SAVE_ROI_IMAGES):
            return None
        fname = f"{prefix}_{int(time.time()*1000)}.png"
        full = os.path.join(self.session_path, fname)
        cv2.imwrite(full, img)
        return full