# bot/bot.py
import threading
import time
import random
import os
import re
from datetime import datetime

from bot.constants import *
from bot.adb_client import AdbWrapper
from bot.vision import Vision
from bot.power_matcher import PowerMatcher
from bot.session_manager import SessionManager
from bot.config_manager import ConfigManager
from bot.logger import GUILogger
from bot.ui_components import UIBuilder
from bot.wheel_spinner import WheelSpinner
from bot.training_spinner import TrainingSpinner
from bot.viking_bot import VikingBot

class EvonyBot:
    def __init__(self, root):
        self.root = root

        self.running_accounts = {}
        self.gui_vars = {
            "modes": {},
            "filters": {},
            "serials": {},
            "stats": {},
            "min_power": {}
        }
        self.filter_buttons_map = {}
        self.status_leds_map = {}
        self.swipe_tracker = {}
        self.help_timer_tracker = {}
        self.dropdown_map = {}

        self.adb = AdbWrapper()
        self.vision = Vision()
        self.power_matcher = PowerMatcher()
        self.config_mgr = ConfigManager()
        self.session = SessionManager()
        self.logger = None

        self.wheel_spinner = None
        self.training_spinner = None
        self.viking_bot = VikingBot(self.adb, self.add_log_entry)

        self.device_list = self.adb.refresh_devices()

        self.ui = UIBuilder(root, self)

        self.load_persistent_config()

        self.add_log_entry("Система готова до роботи.", "🛡️", "SUCCESS")

    def set_logger(self, log_widget):
        self.logger = GUILogger(log_widget)

    def add_log_entry(self, message, icon="ℹ️", level="INFO"):
        if self.logger:
            self.logger.log(message, icon, level)

    def refresh_devices_async(self):
        def worker():
            new_list = self.adb.refresh_devices()
            self.root.after(0, lambda: self._on_devices_refreshed(new_list))
        threading.Thread(target=worker, daemon=True).start()

    def _on_devices_refreshed(self, new_list):
        self.device_list = new_list
        self.update_device_dropdowns(new_list)
        if hasattr(self, 'ui') and hasattr(self.ui, 'wheel_device_dropdown'):
            choices = new_list if new_list else ["None"]
            self.ui.wheel_device_dropdown['values'] = choices
            if choices and choices[0] != "None":
                self.ui.wheel_device_dropdown.current(0)
                self.ui.wheel_device_var.set(choices[0])
        if hasattr(self, 'ui') and hasattr(self.ui, 'training_device_dropdown'):
            choices = new_list if new_list else ["None"]
            self.ui.training_device_dropdown['values'] = choices
            if choices and choices[0] != "None":
                self.ui.training_device_dropdown.current(0)
                self.ui.training_device_var.set(choices[0])
        self.add_log_entry(f"Оновлено список пристроїв: {', '.join(new_list)}", "🔁", "DEBUG")

    def update_device_dropdowns(self, new_device_list):
        choices = new_device_list if new_device_list else ["Пристрої не знайдено"]
        for acc_name, var in self.gui_vars["serials"].items():
            try:
                menu = self.dropdown_map[acc_name]["menu"]
                menu.delete(0, "end")
                for choice in choices:
                    menu.add_command(label=choice, command=lambda v=var, c=choice: v.set(c))
                if var.get() not in choices:
                    var.set("")
            except Exception as e:
                self.add_log_entry(f"Помилка оновлення dropdown для {acc_name}: {e}", "⚠️", "WARN")

    def refresh_power_templates_async(self):
        def worker():
            self.power_matcher.load_templates()
            self.root.after(0, lambda: self.add_log_entry("Оновлено шаблони power.", "🔁", "DEBUG"))
        threading.Thread(target=worker, daemon=True).start()

    def toggle_filter(self, account_name):
        current = self.gui_vars["filters"][account_name].get()
        if current == "OFF":
            self.gui_vars["filters"][account_name].set("ON")
            self.filter_buttons_map[account_name].config(bg=BUTTON_PRIMARY)
        else:
            self.gui_vars["filters"][account_name].set("OFF")
            self.filter_buttons_map[account_name].config(bg=CRIMSON)
        self.save_current_config()

    def set_led_status(self, account_name, is_running):
        color = GREEN_OK if is_running else "#333333"
        self.status_leds_map[account_name].config(bg=color)

    def save_current_config(self):
        data = {}
        for name in [f"Account {i}" for i in range(1,6)]:
            data[name] = {
                "mode": self.gui_vars["modes"][name].get(),
                "filter": self.gui_vars["filters"][name].get(),
                "serial": self.gui_vars["serials"][name].get(),
                "min_power": self.gui_vars["min_power"][name].get()
            }
        self.config_mgr.save(data)

    def load_persistent_config(self):
        data = self.config_mgr.load([f"Account {i}" for i in range(1,6)])
        for name in [f"Account {i}" for i in range(1,6)]:
            if name in data:
                self.gui_vars["modes"][name].set(data[name].get("mode", "M"))
                filt = data[name].get("filter", "OFF")
                self.gui_vars["filters"][name].set(filt)
                if filt == "ON":
                    self.filter_buttons_map[name].config(bg=BUTTON_PRIMARY)
                serial = data[name].get("serial", "")
                if serial in self.device_list:
                    self.gui_vars["serials"][name].set(serial)
                min_p = data[name].get("min_power", "0M")
                self.gui_vars["min_power"][name].set(min_p)

    def start_account(self, account_name):
        self.save_current_config()
        serial = self.gui_vars["serials"][account_name].get()
        if not serial or serial in ("None", "Пристрої не знайдено"):
            self.add_log_entry(f"{account_name}: Пристрій не вибрано!", "❌", "ERROR")
            return
        if self.running_accounts.get(account_name):
            self.add_log_entry(f"{account_name}: Вже запущено.", "⚠️", "WARN")
            return
        self.running_accounts[account_name] = True
        thread = threading.Thread(target=self.account_loop, args=(account_name, serial), daemon=True)
        thread.start()
        self.add_log_entry(f"{account_name}: Процес ініційовано на {serial}", "🚀", "INFO")

    def stop_account(self, account_name):
        if self.running_accounts.get(account_name):
            self.running_accounts[account_name] = False
            self.add_log_entry(f"{account_name}: Отримано команду на зупинку.", "🛑", "WARN")
        else:
            self.add_log_entry(f"{account_name}: Акаунт не активний.", "ℹ️", "INFO")

    # ------------------- Допоміжний метод перевірки гри -----------------
    def ensure_game_foreground(self, device, acc_name):
        """Перевіряє, чи Evony на передньому плані. Якщо ні – намагається запустити."""
        if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
            self.add_log_entry(f"{acc_name}: Гра неактивна. Спроба запуску...", "⚠️", "WARN")
            self.adb.launch_app(device, EVONY_PACKAGE)
            time.sleep(10)  # даємо грі час завантажитись
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                self.add_log_entry(f"{acc_name}: Не вдалося запустити Evony!", "☢️", "ERROR")
                return False
            self.add_log_entry(f"{acc_name}: Гру успішно повернено на передній план.", "✅", "SUCCESS")
        return True

    # ------------------------------------------------------------------

    def account_loop(self, acc_name, serial):
        device = self.adb.get_device(serial)
        if not device:
            self.add_log_entry(f"{acc_name}: Не вдалося підключитись до пристрою {serial}", "☢️", "ERROR")
            self.set_led_status(acc_name, False)
            return

        self.set_led_status(acc_name, True)
        self.swipe_tracker[acc_name] = 0
        self.help_timer_tracker[acc_name] = time.time()

        # Перед початком основного циклу переконуємось, що гра активна
        if not self.ensure_game_foreground(device, acc_name):
            self.set_led_status(acc_name, False)
            return

        while self.running_accounts.get(acc_name):
            try:
                # Періодична перевірка, чи гра не вилетіла
                if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                    self.add_log_entry(f"{acc_name}: Гра зникла з переднього плану. Пробую відновити...", "⚠️", "WARN")
                    if not self.ensure_game_foreground(device, acc_name):
                        break  # не вдалося – зупиняємо акаунт
                    # Після відновлення невелика пауза, щоб гра оновила UI
                    time.sleep(5)

                frame = self.adb.screencap_to_img(device)
                if frame is None:
                    self.add_log_entry(f"{acc_name}: Помилка зв'язку!", "☢️", "ERROR")
                    break

                scan_roi = frame[150:710, :]

                mode = self.gui_vars["modes"][acc_name].get()
                join_tpl = "join_p1.png" if mode == "P1" else "join.png"

                found, loc, score = self.vision.find_template(scan_roi, join_tpl, 0.82)

                if found:
                    abs_x = loc[0]
                    abs_y = loc[1] + 150

                    # ---------- ПЕРЕВІРКА НА ЧЕРВОНЕ РАЛІ ----------
                    is_red = self.vision.has_red_timer(frame, abs_x, abs_y, min_score=0.7)
                    self.add_log_entry(
                        f"{acc_name}: Перевірка червоного таймера — {'ЧЕРВОНЕ' if is_red else 'чисте'} "
                        f"(Join @ x={abs_x}, y={abs_y})",
                        "🔴" if is_red else "🟢", "DEBUG"
                    )

                    if is_red:
                        self.add_log_entry(f"{acc_name}: Червоне ралі (активний бій). Пропускаємо.", "🚫", "INFO")
                        self.adb.swipe(device, 300, 600, 300, 350, 950)
                        time.sleep(1.2)
                        continue

                    # Перевірка на ігнорованого боса (Громовий скорпіон)
                    if self.power_matcher.is_ignored_boss(frame, abs_x, abs_y, acc_name, self.session):
                        self.add_log_entry(f"{acc_name}: Виявлено ігнорованого боса (Громовий скорпіон). Пропускаємо рейд.", "🚫", "INFO")
                        self.adb.swipe(device, 300, 600, 300, 350, 950)
                        time.sleep(1.2)
                        continue

                    # ---------- ФІЛЬТР BOSS: вступати ТІЛЬКИ якщо знайдено шаблон потужності ----------
                    if self.gui_vars["filters"][acc_name].get() == "ON":
                        found_power, tpl_name, power_score, power_loc = self.power_matcher.find_in_join_zone(
                            frame, abs_x, abs_y, account_name=acc_name,
                            session_mgr=self.session, vision=self.vision,
                            logger=self.add_log_entry
                        )
                        if found_power:
                            self.add_log_entry(f"{acc_name}: ✅ Фільтр BOSS: знайдено '{tpl_name}' (score={power_score:.2f}). Вступаємо!", "🔎", "DEBUG")
                        else:
                            self.add_log_entry(f"{acc_name}: 🚫 Фільтр BOSS: шаблон потужності не знайдено. Пропускаємо ралі.", "🔎", "INFO")
                            self.adb.swipe(device, 300, 600, 300, 350, 950)
                            time.sleep(1.2)
                            continue

                    # Якщо фільтр вимкнено або шаблон знайдено — вступаємо
                    self.add_log_entry(f"{acc_name}: Виявлено підходяще ралі. Спроба вступу.", "🔘", "INFO")
                    self.adb.tap(device, abs_x + 60, abs_y + 25)

                    # ---------- Очікування появи кнопки march (або preset1) ----------
                    march_found = False
                    start_wait = time.time()
                    timeout = 10.0  # чекаємо до 10 секунд

                    while time.time() - start_wait < timeout and not march_found:
                        time.sleep(1.0)  # пауза між спробами
                        if not self.running_accounts.get(acc_name):
                            break

                        # Швидка перевірка гри, щоб не застрягти на вильоті
                        if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                            self.add_log_entry(f"{acc_name}: Гра зникла під час вступу. Перериваю очікування.", "⚠️", "WARN")
                            break

                        after_join_frame = self.adb.screencap_to_img(device)
                        if after_join_frame is None:
                            continue

                        # Якщо ввімкнено режим P1 – спочатку шукаємо preset1
                        if mode == "P1":
                            p_found, p_loc, p_score = self.vision.find_template(after_join_frame, "preset1.png", 0.78)
                            if p_found:
                                self.adb.tap(device, p_loc[0] + 20, p_loc[1] + 20)
                                self.add_log_entry(f"{acc_name}: Натиснув preset1 (score={p_score:.2f}).", "🔘", "INFO")
                                time.sleep(1.2)  # дати час на реакцію гри
                            else:
                                self.add_log_entry(f"{acc_name}: Очікування preset1... (score={p_score:.3f})", "⏳", "DEBUG")

                        # Пошук march (у будь-якому режимі)
                        m_found, m_loc, m_score = self.vision.find_template(after_join_frame, "march.png", 0.75)
                        if m_found:
                            self.adb.tap(device, m_loc[0] + 65, m_loc[1] + 30)
                            self.add_log_entry(f"{acc_name}: Натиснув МАРШ.", "⚔️", "SUCCESS")
                            old = self.gui_vars["stats"][acc_name].get()
                            self.gui_vars["stats"][acc_name].set(old + 1)
                            march_found = True
                            break
                        else:
                            self.add_log_entry(f"{acc_name}: Очікування кнопки march... (score={m_score:.3f})", "⏳", "DEBUG")

                    if not march_found:
                        self.add_log_entry(f"{acc_name}: Кнопка 'march' не з'явилась протягом {timeout}с. Вихід з рейду.", "⚠️", "WARN")
                        self.adb.keyevent(device, 4)
                        time.sleep(1.0)

                else:
                    header_check = self.vision.find_template(frame[0:120, :], "war_menu_label.png", 0.72)
                    if header_check[0]:
                        now = time.time()
                        if now - self.help_timer_tracker[acc_name] > 360:
                            self.adb.keyevent(device, 4)
                            self.help_timer_tracker[acc_name] = now
                        else:
                            self.swipe_tracker[acc_name] += 1
                            if self.swipe_tracker[acc_name] >= 4:
                                self.adb.swipe(device, 300, 250, 300, 900, 1200)
                                self.swipe_tracker[acc_name] = 0
                            else:
                                self.adb.swipe(device, 300, 600, 300, 350, 950)
                    else:
                        if not self.navigate_to_war(device, acc_name):
                            self.adb.keyevent(device, 4)
                            time.sleep(3.0)

                time.sleep(random.uniform(2.8, 5.2))

            except Exception as e:
                self.add_log_entry(f"{acc_name}: Помилка циклу: {e}", "☢️", "ERROR")
                time.sleep(6.0)

        self.set_led_status(acc_name, False)

    def _parse_power_string(self, s):
        s = s.upper().strip()
        if not s:
            return 0.0
        s = s.replace(" ", "")
        match = re.match(r"^([\d.]+)([KMB]?)", s)
        if not match:
            return 0.0
        num_str, suffix = match.groups()
        try:
            num = float(num_str)
        except:
            return 0.0
        if suffix == 'K':
            return num / 1000.0
        elif suffix == 'M':
            return num
        elif suffix == 'B':
            return num * 1000.0
        else:
            return num

    def navigate_to_war(self, device, acc_name):
        self.add_log_entry(f"{acc_name}: Відновлення навігації...", "🔄", "WARN")
        try:
            frame = self.adb.screencap_to_img(device)
            if frame is None:
                return False
            found, loc, _ = self.vision.find_template(frame, "alliance_btn.png", 0.77)
            if found:
                self.adb.tap(device, loc[0] + 30, loc[1] + 30)
                time.sleep(3.0)
                inner = self.adb.screencap_to_img(device)
                if inner is not None:
                    self.alliance_help(device, inner, acc_name)
                for _ in range(8):
                    time.sleep(1.5)
                    war_frame = self.adb.screencap_to_img(device)
                    if war_frame is None:
                        continue
                    w_found, w_loc, _ = self.vision.find_template(war_frame, "alliance_war_entry.png", 0.70)
                    if w_found:
                        self.adb.tap(device, w_loc[0] + 130, w_loc[1] + 30)
                        self.add_log_entry(f"{acc_name}: Увійшов у Війну.", "✅", "SUCCESS")
                        time.sleep(2.5)
                        return True
        except Exception as e:
            self.add_log_entry(f"{acc_name}: Помилка навігації: {e}", "☢️", "ERROR")
        return False

    def alliance_help(self, device, current_screen, acc_name):
        found, loc, val = self.vision.find_template(current_screen, "help_badge.png", 0.81)
        if found:
            self.add_log_entry(f"{acc_name}: Натискаю на допомогу...", "🤝", "INFO")
            self.adb.tap(device, loc[0] - 40, loc[1] + 30)
            time.sleep(3.2)
            help_screen = self.adb.screencap_to_img(device)
            if help_screen is not None:
                btn_found, btn_loc, _ = self.vision.find_template(help_screen, "help_all_btn.png", 0.76)
                if btn_found:
                    self.adb.tap(device, btn_loc[0] + 155, btn_loc[1] + 35)
                    self.add_log_entry(f"{acc_name}: Допомога надана успішно.", "✅", "SUCCESS")
                    time.sleep(2.0)
            self.adb.keyevent(device, 4)
            time.sleep(1.8)