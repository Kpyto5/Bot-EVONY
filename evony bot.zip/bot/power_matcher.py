# bot/power_matcher.py
import cv2
import numpy as np
import os
import re
from datetime import datetime
from bot.constants import *

class PowerMatcher:
    def __init__(self, power_dir=DIR_POWER):
        self.power_dir = power_dir
        self.power_templates = []      # шаблони з числовою потужністю (дозволені боси)
        self.ignored_templates = []    # шаблони ігнорованих босів (thunder_scorpion тощо)
        self.allowed_powers = []       # список унікальних потужностей (для інформації)
        self.load_templates()

        # ROI для майбутнього використання (поки не застосовується в основному циклі)
        self.after_join_roi = (400, 150, 700, 300)

    def _parse_filename_power(self, fname):
        """
        Витягує потужність із назви файлу. Підтримує:
        '130.png'  -> 130M, '22.3.png' -> 22.3M,
        '1.5B.png' -> 1500M, '500K.png' -> 0.5M.
        """
        name = os.path.splitext(fname)[0].strip().upper()
        name = name.replace(',', '.')
        match = re.match(r'^([\d]+(?:\.\d+)?)([KMB]?)$', name)
        if not match:
            return None
        num_str, suffix = match.groups()
        try:
            num = float(num_str)
        except ValueError:
            return None
        if suffix == 'K':
            return num / 1000.0
        elif suffix == 'B':
            return num * 1000.0
        else:
            return num  # M або без суфікса

    def load_templates(self):
        """Завантажує всі шаблони з папки power/."""
        self.power_templates = []
        self.ignored_templates = []
        self.allowed_powers = []

        if not os.path.exists(self.power_dir):
            return

        for fname in os.listdir(self.power_dir):
            if not fname.lower().endswith('.png'):
                continue
            base = os.path.splitext(fname)[0]

            # Шаблон ігнорованого боса (назва в IGNORED_BOSS_TEMPLATES)
            if base in IGNORED_BOSS_TEMPLATES:
                full = os.path.join(self.power_dir, fname)
                img = cv2.imread(full, cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    self.ignored_templates.append({
                        'name': fname,
                        'gray': img,
                        'h': img.shape[0],
                        'w': img.shape[1]
                    })
                continue

            # Звичайний шаблон потужності (назва = число)
            power_val = self._parse_filename_power(fname)
            if power_val is not None:
                full = os.path.join(self.power_dir, fname)
                img = cv2.imread(full, cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    self.power_templates.append({
                        'name': fname,
                        'gray': img,
                        'h': img.shape[0],
                        'w': img.shape[1],
                        'power': power_val
                    })
                    self.allowed_powers.append(power_val)

        # Унікальний відсортований список
        self.allowed_powers = sorted(list(set(self.allowed_powers)))

    # ------------------- Допоміжні методи пошуку -------------------
    def _match_gray(self, roi_gray, tpl_gray):
        """
        Порівнює шаблон з ROI в grayscale.
        Повертає (score, location, density).
        density – частка пікселів у матриці результатів, де значення > 0.5 * max_val.
        """
        if roi_gray.shape[0] < tpl_gray.shape[0] or roi_gray.shape[1] < tpl_gray.shape[1]:
            return 0.0, (0, 0), 0.0

        result = cv2.matchTemplate(roi_gray, tpl_gray, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)

        # Оцінка щільності – відкидає випадкові збіги на дуже малій площі
        high_mask = (result >= 0.5 * max_val).astype(np.uint8)
        density = np.count_nonzero(high_mask) / high_mask.size
        return float(max_val), max_loc, density

    def _multi_scale_match(self, roi_gray, tpl_gray, tpl_w, tpl_h, scales=None):
        """
        Масштабує шаблон і знаходить найкращий збіг.
        Повертає (best_score, best_loc, best_scale, best_density).
        """
        if scales is None:
            scales = [0.95, 1.0, 1.05]

        best_score = 0.0
        best_loc = (0, 0)
        best_scale = 1.0
        best_density = 0.0

        rh, rw = roi_gray.shape[:2]
        for s in scales:
            new_w = int(tpl_w * s)
            new_h = int(tpl_h * s)
            if new_w < 8 or new_h < 8 or new_w > rw or new_h > rh:
                continue
            tpl_resized = cv2.resize(tpl_gray, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            score, loc, density = self._match_gray(roi_gray, tpl_resized)

            # Невеликий штраф за низьку щільність
            if density < DENSITY_THRESHOLD:
                score *= 0.9

            if score > best_score:
                best_score = score
                best_loc = loc
                best_scale = s
                best_density = density

        return best_score, best_loc, best_scale, best_density

    # ------------------- Публічні методи -------------------
    def find_in_join_zone(self, full_frame, join_x, join_y, account_name=None,
                          session_mgr=None, vision=None, logger=None):
        """
        Шукає шаблон дозволеної потужності боса в ROI навколо кнопки Join.
        Використовує зміщення з constants.py.
        Повертає (found, template_name, score, (x, y)).
        """
        if not self.power_templates:
            if logger:
                logger("⚠️ Немає завантажених шаблонів потужності.", "⚠️", "WARN")
            if session_mgr:
                session_mgr.append_event({
                    "time": datetime.now().isoformat(),
                    "account": account_name,
                    "event": "no_power_templates"
                })
            return False, None, 0.0, (0, 0)

        h, w = full_frame.shape[:2]

        # Обчислення ROI на основі зміщень з constants.py
        x1 = max(0, join_x + POWER_ROI_OFFSET_LEFT)
        x2 = min(w, join_x + POWER_ROI_OFFSET_RIGHT)
        y1 = max(0, join_y + POWER_ROI_OFFSET_TOP)
        y2 = min(h, join_y + POWER_ROI_OFFSET_BOTTOM)

        if x2 <= x1 or y2 <= y1:
            if logger:
                logger(f"❌ ROI невалідний: x1={x1}, x2={x2}, y1={y1}, y2={y2}", "❌", "DEBUG")
            return False, None, 0.0, (0, 0)

        roi = full_frame[y1:y2, x1:x2]
        if roi.size == 0:
            return False, None, 0.0, (0, 0)

        roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # Збереження ROI для налагодження (якщо увімкнено SAVE_ROI_IMAGES)
        if DETAILED_LOGGING and SAVE_ROI_IMAGES and session_mgr:
            session_mgr.save_image(roi, f"roi_{account_name}_{join_x}_{join_y}")

        best_score = 0.0
        best_tpl = None
        best_loc = (0, 0)
        best_density = 0.0

        for tpl in self.power_templates:
            score, loc, scale, density = self._multi_scale_match(
                roi_gray, tpl['gray'], tpl['w'], tpl['h'],
                scales=POWER_SCALES   # використовуємо масштаби з constants
            )
            if score > best_score:
                best_score = score
                best_tpl = tpl
                best_loc = loc
                best_density = density

        # Логування для діагностики, навіть якщо збіг не перевищив поріг
        if logger:
            if best_tpl:
                logger(
                    f"🔎 ROI [{x1},{y1},{x2},{y2}] | Найкращий збіг: '{best_tpl['name']}' "
                    f"score={best_score:.3f}, dens={best_density:.3f}",
                    "🔍", "DEBUG"
                )
            else:
                logger(
                    f"🔎 ROI [{x1},{y1},{x2},{y2}] | Жодного збігу вище 0",
                    "🔍", "DEBUG"
                )

        if best_score >= POWER_MATCH_THRESHOLD and best_density >= DENSITY_THRESHOLD:
            abs_x = x1 + best_loc[0]
            abs_y = y1 + best_loc[1]
            if logger:
                logger(
                    f"✅ Знайдено '{best_tpl['name']}' (power={best_tpl['power']}M), "
                    f"score={best_score:.3f}, dens={best_density:.3f}, pos=({abs_x},{abs_y})",
                    "✅", "DEBUG"
                )
            if session_mgr:
                session_mgr.append_event({
                    "time": datetime.now().isoformat(),
                    "account": account_name,
                    "event": "power_template_matched",
                    "template": best_tpl['name'],
                    "score": best_score,
                    "power": best_tpl['power'],
                    "density": best_density,
                    "coords": [abs_x, abs_y]
                })
            return True, best_tpl['name'], best_score, (abs_x, abs_y)

        return False, None, best_score, (0, 0)

    def detect_boss_power(self, frame, account_name=None, session_mgr=None):
        """
        Визначає потужність боса після вступу в рейд (зараз не використовується).
        Повертає значення в M або None.
        """
        if not self.power_templates or frame is None:
            return None
        x1, y1, x2, y2 = self.after_join_roi
        h, w = frame.shape[:2]
        x2 = min(x2, w)
        y2 = min(y2, h)
        if x1 >= x2 or y1 >= y2:
            return None
        roi = frame[y1:y2, x1:x2]
        if roi.size == 0:
            return None
        roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        best_score = 0.0
        best_power = None
        for tpl in self.power_templates:
            score, loc, scale, density = self._multi_scale_match(roi_gray, tpl['gray'], tpl['w'], tpl['h'])
            if score > best_score:
                best_score = score
                best_power = tpl['power']
        if best_score >= POWER_MATCH_THRESHOLD and best_power is not None:
            if session_mgr:
                session_mgr.append_event({
                    "time": datetime.now().isoformat(),
                    "account": account_name,
                    "event": "boss_power_detected",
                    "power": best_power,
                    "score": best_score
                })
            return best_power
        return None

    def is_ignored_boss(self, full_frame, join_x, join_y, account_name=None, session_mgr=None):
        """
        Перевіряє наявність ігнорованого боса (наприклад, thunder_scorpion) біля кнопки Join.
        """
        if not self.ignored_templates:
            return False

        h_full, w_full = full_frame.shape[:2]
        x1 = max(0, join_x + POWER_ROI_OFFSET_LEFT)
        x2 = min(w_full, join_x + POWER_ROI_OFFSET_RIGHT)
        y1 = max(0, join_y + POWER_ROI_OFFSET_TOP)
        y2 = min(h_full, join_y + POWER_ROI_OFFSET_BOTTOM)

        if x2 <= x1 or y2 <= y1:
            return False

        roi = full_frame[y1:y2, x1:x2]
        roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        rh, rw = roi_gray.shape[:2]

        for tpl in self.ignored_templates:
            th, tw = tpl['h'], tpl['w']
            for scale in [0.8, 0.9, 1.0, 1.1, 1.2]:
                new_w = int(tw * scale)
                new_h = int(th * scale)
                if new_w < 8 or new_h < 8 or new_w > rw or new_h > rh:
                    continue
                tpl_resized = cv2.resize(tpl['gray'], (new_w, new_h), interpolation=cv2.INTER_LINEAR)
                score, loc, _ = self._match_gray(roi_gray, tpl_resized)
                if score >= POWER_MATCH_THRESHOLD:
                    if session_mgr:
                        session_mgr.append_event({
                            "time": datetime.now().isoformat(),
                            "account": account_name,
                            "event": "ignored_boss_by_template",
                            "template": tpl['name'],
                            "score": float(score)
                        })
                    return True
        return False