# bot/training_spinner.py
import time
import threading
import os
import cv2
from bot.constants import DIR_TRAINING_TEMPLATES, DEBUG_DIR, EVONY_PACKAGE
from bot.adb_client import AdbWrapper
from bot.vision import Vision

class TrainingSpinner:
    def __init__(self, adb: AdbWrapper, vision: Vision, logger_callback):
        self.adb = adb
        self.vision = vision
        self.logger = logger_callback
        self.device_serial = None
        self.is_running = False
        self.cycles = 0
        self.target_cycles = 0
        self.delay = 2.0
        self.templates = {
            "train": "train.png",
            "accelerate": "accelerate.png",
            "complete": "complete.png"
        }
        self.stop_template = "stop_button.png"

    def set_device(self, serial):
        self.device_serial = serial

    def set_target_cycles(self, cycles):
        self.target_cycles = cycles

    def set_delay(self, delay):
        self.delay = delay

    def get_cycles(self):
        return self.cycles

    def reset_cycles(self):
        self.cycles = 0

    def start(self):
        if not self.device_serial:
            self.logger("Пристрій не вибрано!", "❌", "ERROR")
            return False
        if self.is_running:
            return False
        self.is_running = True
        threading.Thread(target=self._loop, daemon=True).start()
        return True

    def stop(self):
        self.is_running = False

    def _check_stop_condition(self, device):
        stop_path = os.path.join(DIR_TRAINING_TEMPLATES, self.stop_template)
        if not os.path.exists(stop_path):
            return False
        screen = self.adb.screencap_to_img(device)
        if screen is None:
            return False
        tpl = cv2.imread(stop_path)
        if tpl is None:
            return False
        try:
            res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(res)
            if max_val >= 0.8:
                self.logger(f"Виявлено шаблон зупинки (score={max_val:.3f}) – завершення роботи.", "🛑", "WARN")
                return True
        except Exception as e:
            self.logger(f"Помилка перевірки шаблону зупинки: {e}", "❌", "ERROR")
        return False

    def _ensure_game(self, device):
        if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
            self.logger("Гра неактивна. Спроба запуску...", "⚠️", "WARN")
            self.adb.launch_app(device, EVONY_PACKAGE)
            time.sleep(10)
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                self.logger("Не вдалося запустити Evony!", "☢️", "ERROR")
                return False
            self.logger("Гру повернено на передній план.", "✅", "SUCCESS")
        return True

    def _loop(self):
        self.logger("=== СТАРТ ТРЕНУВАННЯ ВІЙСЬК ===", "⚔️", "INFO")
        device = self.adb.get_device(self.device_serial)
        if not device:
            self.logger(f"Не вдалося підключитись до {self.device_serial}", "❌", "ERROR")
            return

        if not self._ensure_game(device):
            self.is_running = False
            return

        while self.is_running:
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                if not self._ensure_game(device):
                    break

            if self._check_stop_condition(device):
                self.is_running = False
                break

            if self.target_cycles > 0 and self.cycles >= self.target_cycles:
                self.logger(f"Досягнуто цільової кількості циклів: {self.target_cycles}", "✅", "INFO")
                break

            if not self._find_and_click(device, "train", 0.75):
                self.logger("Не знайдено кнопку 'train'. Зупинка.", "❌", "ERROR")
                break
            self.logger("Натиснуто 'train'.", "🔘", "INFO")
            time.sleep(1.0)

            if not self._find_and_click(device, "accelerate", 0.75):
                self.logger("Не знайдено кнопку 'accelerate'. Зупинка.", "❌", "ERROR")
                break
            self.logger("Натиснуто 'accelerate'.", "⚡", "INFO")
            time.sleep(1.0)

            if not self._find_and_click(device, "complete", 0.75):
                self.logger("Не знайдено кнопку 'complete'. Зупинка.", "❌", "ERROR")
                break
            self.logger("Натиснуто 'complete'.", "✅", "INFO")

            self.cycles += 1
            self.logger(f"Цикл {self.cycles} завершено.", "🔄", "SUCCESS")

            if self.is_running and not (self.target_cycles > 0 and self.cycles >= self.target_cycles):
                self.logger(f"Пауза {self.delay} сек перед наступним циклом.", "⏱️", "DEBUG")
                time.sleep(self.delay)

        self.is_running = False
        self.logger("=== ЗУПИНКА ТРЕНУВАННЯ ВІЙСЬК ===", "🛑", "INFO")

    def _find_and_click(self, device, template_key, threshold=0.75):
        template_name = self.templates.get(template_key)
        if not template_name:
            self.logger(f"Невідомий ключ шаблону: {template_key}", "❌", "ERROR")
            return False

        path = os.path.join(DIR_TRAINING_TEMPLATES, template_name)
        if not os.path.exists(path):
            self.logger(f"Шаблон не знайдено: {path}", "❌", "ERROR")
            return False

        screen = self.adb.screencap_to_img(device)
        if screen is None:
            self.logger("Не вдалося отримати скріншот для пошуку шаблону.", "⚠️", "ERROR")
            return False

        tpl = cv2.imread(path)
        if tpl is None:
            self.logger(f"Не вдалося завантажити шаблон: {path}", "❌", "ERROR")
            return False

        try:
            res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
        except Exception as e:
            self.logger(f"Помилка під час порівняння шаблону {template_key}: {e}", "❌", "ERROR")
            return False

        self.logger(f"Пошук {template_key}: max_val={max_val:.3f}", "🔍", "DEBUG")
        if max_val >= threshold:
            h, w = tpl.shape[:2]
            x, y = max_loc[0] + w//2, max_loc[1] + h//2
            self.adb.tap(device, x, y)
            return True
        else:
            self.logger(f"Шаблон {template_key} не знайдено (score={max_val:.3f})", "⚠️", "WARN")
            return False