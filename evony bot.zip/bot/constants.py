# bot/constants.py
import os

# Коренева папка проєкту (на один рівень вище від цього файлу)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Кольори
BG_COLOR = "#0f0b07"
PANEL_COLOR = "#1f1710"
HEADER_COLOR = "#2b1a00"
GOLD_ACCENT = "#d4b36a"
BUTTON_PRIMARY = "#5a3b1a"
BUTTON_PRIMARY_HOVER = "#7a4f26"
BUTTON_SECONDARY = "#3b2a4a"
CRIMSON = "#b22222"
GREEN_OK = "#2ecc71"
TEXT_LIGHT = "#f4e4bc"
LOG_BG = "#070606"
LOG_FG = "#e9e6df"

# Шляхи до папок
DIR_TEMPLATES = os.path.join(BASE_DIR, "templates")
DIR_WHEEL_TEMPLATES = os.path.join(DIR_TEMPLATES, "wheel_spinner")
DIR_TRAINING_TEMPLATES = os.path.join(DIR_TEMPLATES, "training troops")
DIR_POWER = os.path.join(DIR_TEMPLATES, "power")
DIR_LOGS = os.path.join(BASE_DIR, "logs")
DIR_SESSIONS = os.path.join(DIR_LOGS, "sessions")
DEBUG_DIR = os.path.join(BASE_DIR, "debug_screens")

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
SESSIONS_INDEX = os.path.join(DIR_LOGS, "sessions_index.json")

# Параметри ADB
ADB_HOST = "127.0.0.1"
ADB_PORT = 5037

# Параметри пошуку потужності (шаблонний матчінг)
POWER_MATCH_THRESHOLD = 0.90          # поріг для збігу (раніше було 0.80, потім 0.92; 0.90 – баланс)
POWER_FALLBACK_THRESHOLD = 0.74
POWER_SCALES = [0.9, 0.95, 1.0, 1.05, 1.1]   # трохи розширено для надійності
EDGE_BLUR = 3
DENSITY_THRESHOLD = 0.10             # мінімальна щільність (було 0.12, зменшено)
# Зміщення ROI відносно join_x, join_y (координати верхнього лівого кута кнопки Join)
POWER_ROI_OFFSET_LEFT = -200         # ліва межа: join_x - 200
POWER_ROI_OFFSET_RIGHT = 200         # права: join_x + 200
POWER_ROI_OFFSET_TOP = -130          # верхня: join_y - 130 (сила над кнопкою)
POWER_ROI_OFFSET_BOTTOM = -10        # нижня: join_y - 10   (не зачіпає саму кнопку)

# Налаштування логування сесій
DETAILED_LOGGING = True
SAVE_ROI_IMAGES = True
LOG_CANDIDATES_CSV = True

# ---------- Ігноровані боси (шаблони у папці templates/power) ----------
IGNORED_BOSS_TEMPLATES = ["thunder_scorpion"]   # назва файлу без .png

# ---------- Перевірка активності гри ----------
EVONY_PACKAGE = "com.topgamesinc.evony"