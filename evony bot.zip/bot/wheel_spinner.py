# bot/wheel_spinner.py
import time
import threading
import os
import cv2
import numpy as np
from datetime import datetime
from bot.constants import DIR_WHEEL_TEMPLATES, DEBUG_DIR, EVONY_PACKAGE
from bot.adb_client import AdbWrapper
from bot.vision import Vision

class WheelSpinner:
    def __init__(self, adb: AdbWrapper, vision: Vision, logger_callback):
        self.adb = adb
        self.vision = vision
        self.logger = logger_callback
        self.device_serial = None
        self.is_running = False
        self.counter = 0
        self.delay = 1.5
        self.mode = "spin_100"

    def set_device(self, serial):
        self.device_serial = serial

    def set_mode(self, mode):
        self.mode = mode

    def set_delay(self, delay):
        self.delay = delay

    def set_counter(self, value):
        self.counter = value

    def get_counter(self):
        return self.counter

    def start(self):
        if not self.device_serial:
            self.logger("Пристрій не вибрано!", "❌", "ERROR")
            return False
        if self.is_running:
            return False
        self.is_running = True
        threading.Thread(target=self._loop, daemon=True).start()
        return True

    def stop(self):
        self.is_running = False

    def _ensure_game(self, device):
        if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
            self.logger("Гра неактивна. Спроба запуску...", "⚠️", "WARN")
            self.adb.launch_app(device, EVONY_PACKAGE)
            time.sleep(10)
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                self.logger("Не вдалося запустити Evony!", "☢️", "ERROR")
                return False
            self.logger("Гру повернено на передній план.", "✅", "SUCCESS")
        return True

    def _loop(self):
        self.logger("=== СТАРТ СЕСІЇ КОЛЕСА ===", "🎡", "INFO")
        device = self.adb.get_device(self.device_serial)
        if not device:
            self.logger(f"Не вдалося підключитись до {self.device_serial}", "❌", "ERROR")
            return

        if not self._ensure_game(device):
            self.is_running = False
            return

        while self.is_running:
            # Перевірка перед кожною ітерацією
            if not self.adb.is_app_foreground(device, EVONY_PACKAGE):
                if not self._ensure_game(device):
                    break

            in_menu = self._check_if_in_menu(device)
            if not in_menu:
                self.logger("Вважаю, що не в меню Колеса. Спробую знайти іконку івенту...", "🔍", "INFO")
                if self._find_and_click(device, "event_icon", 0.7):
                    time.sleep(3.0)
                    continue
                else:
                    self.logger("Не знайдено іконку івенту на екрані.", "⚠️", "WARN")

            should_press_back = not in_menu
            if not should_press_back:
                if self._is_popup_present(device):
                    should_press_back = True

            if should_press_back:
                self.adb.keyevent(device, 4)
                self.logger("Надіслано BACK (початкове очищення).", "⌫", "DEBUG")

            time.sleep(self.delay)
            if not self.is_running:
                break

            if self._find_and_click(device, self.mode, 0.85):
                self.counter += 1
                self.logger(f"Клік {self.mode} успішний. Всього: {self.counter}", "🔄", "SUCCESS")
                if self._wait_for_reward_popup(device, timeout=8):
                    self.adb.keyevent(device, 4)
                    self.logger("Надіслано BACK після нагородження.", "🎁", "INFO")
                    time.sleep(1.0)
                else:
                    self.logger("Попап не з'явився, продовжую без закриття.", "⚠️", "WARN")
            else:
                self.logger(f"Не вдалося натиснути {self.mode}, можливо, кнопка не знайдена.", "❌", "WARN")

            time.sleep(self.delay)

        self.logger("=== ЗУПИНКА СЕСІЇ КОЛЕСА ===", "🛑", "INFO")

    def _check_if_in_menu(self, device):
        screen = self.adb.screencap_to_img(device)
        if screen is None:
            self.logger("check_if_in_menu: не вдалося отримати скріншот.", "⚠️", "ERROR")
            return False
        anchors = ["wheel_title.png", "event_icon.png"]
        best_val = 0.0
        best_tpl = None
        scales = np.linspace(0.85, 1.15, 7)
        for tpl_name in anchors:
            path = os.path.join(DIR_WHEEL_TEMPLATES, tpl_name)
            if not os.path.exists(path):
                continue
            val, _, _ = self.vision.find_template_scaled(screen, path, scales=scales)
            if val > best_val:
                best_val = val
                best_tpl = tpl_name
        threshold = 0.75
        if best_val >= threshold:
            self.logger(f"check_if_in_menu: Якір знайдено {best_tpl} val={best_val:.3f}", "🔍", "DEBUG")
            return True
        debug_path = os.path.join(DEBUG_DIR, f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        cv2.imwrite(debug_path, screen)
        self.logger(f"check_if_in_menu: Якір не знайдено. Збережено скріншот {debug_path}. Найкращий val={best_val:.3f}", "⚠️", "DEBUG")
        return False

    def _find_and_click(self, device, template_name, threshold=0.8):
        path = os.path.join(DIR_WHEEL_TEMPLATES, f"{template_name}.png")
        if not os.path.exists(path):
            self.logger(f"Шаблон не знайдено: {path}", "❌", "ERROR")
            return False
        screen = self.adb.screencap_to_img(device)
        if screen is None:
            self.logger("Не вдалося отримати скріншот для пошуку шаблону.", "⚠️", "ERROR")
            return False
        tpl = cv2.imread(path)
        if tpl is None:
            self.logger(f"Не вдалося завантажити шаблон: {path}", "❌", "ERROR")
            return False
        try:
            res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
        except Exception as e:
            self.logger(f"Помилка під час порівняння шаблону: {e}", "❌", "ERROR")
            return False
        self.logger(f"find_and_click: {template_name} max_val={max_val:.3f}", "🔍", "DEBUG")
        if max_val >= threshold:
            h, w = tpl.shape[:2]
            x, y = max_loc[0] + w//2, max_loc[1] + h//2
            self.adb.tap(device, x, y)
            return True
        return False

    def _wait_for_reward_popup(self, device, timeout=8):
        popup_path = os.path.join(DIR_WHEEL_TEMPLATES, "reward_popup.png")
        if not os.path.exists(popup_path):
            self.logger("Шаблон reward_popup.png відсутній. Очікування попапу пропущено.", "⚠️", "WARN")
            return False
        start_time = time.time()
        scales = np.linspace(0.8, 1.2, 5)
        while time.time() - start_time < timeout:
            screen = self.adb.screencap_to_img(device)
            if screen is None:
                time.sleep(0.5)
                continue
            try:
                tpl = cv2.imread(popup_path)
                if tpl is None:
                    return False
                best_val = 0.0
                for scale in scales:
                    new_w = max(1, int(tpl.shape[1] * scale))
                    new_h = max(1, int(tpl.shape[0] * scale))
                    tpl_resized = cv2.resize(tpl, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
                    if screen.shape[0] < new_h or screen.shape[1] < new_w:
                        continue
                    res = cv2.matchTemplate(screen, tpl_resized, cv2.TM_CCOEFF_NORMED)
                    _, max_val, _, _ = cv2.minMaxLoc(res)
                    best_val = max(best_val, max_val)
                    if best_val >= 0.7:
                        self.logger(f"Знайдено попап нагородження з коефіцієнтом {best_val:.3f}", "🎁", "INFO")
                        return True
            except Exception as e:
                self.logger(f"Помилка при пошуку попапу: {e}", "❌", "ERROR")
            time.sleep(0.3)
        self.logger(f"Попап не з'явився за {timeout} секунд.", "⚠️", "WARN")
        return False

    def _is_popup_present(self, device):
        popup_path = os.path.join(DIR_WHEEL_TEMPLATES, "reward_popup.png")
        if not os.path.exists(popup_path):
            return False
        screen = self.adb.screencap_to_img(device)
        if screen is None:
            return False
        tpl = cv2.imread(popup_path)
        if tpl is None:
            return False
        if screen.shape[0] >= tpl.shape[0] and screen.shape[1] >= tpl.shape[1]:
            res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(res)
            return max_val >= 0.75
        return False