# bot/vision.py
import cv2
import numpy as np
import os
from bot.constants import DIR_TEMPLATES

class Vision:
    def __init__(self, templates_path=DIR_TEMPLATES):
        self.templates_path = templates_path
        self._tpl_cache = {}

    def _load_tpl(self, full_path):
        """Кешує шаблони щоб не читати з диску кожен раз."""
        if full_path not in self._tpl_cache:
            img = cv2.imread(full_path)
            if img is not None:
                self._tpl_cache[full_path] = img
        return self._tpl_cache.get(full_path)

    def _match(self, screen_gray, tpl_gray):
        """
        Порівняння в grayscale — нечутливе до різниці яскравості/гами між емуляторами.
        Повертає (max_val, max_loc).
        """
        if screen_gray.shape[0] < tpl_gray.shape[0] or screen_gray.shape[1] < tpl_gray.shape[1]:
            return 0.0, (0, 0)
        result = cv2.matchTemplate(screen_gray, tpl_gray, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        return float(max_val), max_loc

    def find_template(self, screen_img, template_name, min_score=0.75):
        """
        Пошук шаблону в grayscale — працює однаково на LDPlayer і MEmu.
        Повертає (found, (x, y), score).
        """
        full_path = os.path.join(self.templates_path, template_name)
        if not os.path.exists(full_path):
            return False, (0, 0), 0.0
        tpl = self._load_tpl(full_path)
        if tpl is None:
            return False, (0, 0), 0.0

        screen_gray = cv2.cvtColor(screen_img, cv2.COLOR_BGR2GRAY)
        tpl_gray    = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)

        max_val, max_loc = self._match(screen_gray, tpl_gray)
        if max_val >= min_score:
            return True, max_loc, max_val
        return False, (0, 0), max_val

    def find_template_scaled(self, screen_img, template_path, scales=None, method=cv2.TM_CCOEFF_NORMED):
        """
        Пошук шаблону з масштабуванням в grayscale.
        Повертає (max_val, (x, y), scale).
        """
        if scales is None:
            scales = [1.0]
        tpl = self._load_tpl(template_path)
        if tpl is None:
            return 0.0, None, None

        screen_gray = cv2.cvtColor(screen_img, cv2.COLOR_BGR2GRAY)
        tpl_gray    = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
        th, tw = tpl_gray.shape[:2]

        best_val   = 0.0
        best_loc   = None
        best_scale = None

        for s in scales:
            new_w = max(1, int(tw * s))
            new_h = max(1, int(th * s))
            if screen_gray.shape[0] < new_h or screen_gray.shape[1] < new_w:
                continue
            tpl_resized = cv2.resize(tpl_gray, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            res = cv2.matchTemplate(screen_gray, tpl_resized, method)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val > best_val:
                best_val   = max_val
                best_loc   = max_loc
                best_scale = s

        return best_val, best_loc, best_scale

    def is_red_rally(self, frame, btn_x, btn_y):
        """Старий метод — залишено для сумісності."""
        h, w = frame.shape[:2]
        roi_x1 = max(0, btn_x - 50)
        roi_x2 = min(w, btn_x + 150)
        roi_y1 = max(0, btn_y - 60)
        roi_y2 = max(0, btn_y - 5)
        if roi_x2 <= roi_x1 or roi_y2 <= roi_y1:
            return False
        roi = frame[roi_y1:roi_y2, roi_x1:roi_x2]
        if roi.size == 0:
            return False
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        lower_red1 = np.array([0, 100, 80])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 100, 80])
        upper_red2 = np.array([180, 255, 255])
        mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
        red_mask = cv2.bitwise_or(mask1, mask2)
        red_mask = cv2.medianBlur(red_mask, 3)
        red_pixels = np.count_nonzero(red_mask)
        total_pixels = roi.shape[0] * roi.shape[1]
        red_ratio = red_pixels / total_pixels if total_pixels > 0 else 0.0
        return red_ratio > 0.05

    def has_red_timer(self, frame, btn_x, btn_y, min_score=0.7):
        """
        Перевірка чи ралі вже активне — визначає червоний текст таймера
        всередині кнопки 'Вступить 00:00:31' (червоний колір = зайняте ралі).

        Метод 1: HSV-маска на зоні кнопки — шукає яскраво-червоний текст таймера.
                 Вікно обмежене ТІЛЬКИ кнопкою, тому темно-червоний фон карток
                 босів (який знаходиться вище) не потрапляє в ROI.
        Метод 2: Шаблони (red_timer.png, join_timer.png) як додаткова перевірка.
        """
        h, w = frame.shape[:2]

        # ROI = точно зона кнопки Join (нижній рядок картки)
        # btn_x, btn_y — це координати де знайдено шаблон join.png
        # Кнопка знаходиться ПРАВОРУЧ від таймера, приблизно 120x40 пікселів
        bx1 = max(0, btn_x)
        bx2 = min(w, btn_x + 130)
        by1 = max(0, btn_y + 5)
        by2 = min(h, btn_y + 45)

        if bx2 <= bx1 or by2 <= by1:
            return False

        btn_roi = frame[by1:by2, bx1:bx2]
        if btn_roi.size == 0:
            return False

        # --- Метод 1: HSV — яскраво-червоний текст таймера всередині кнопки ---
        hsv = cv2.cvtColor(btn_roi, cv2.COLOR_BGR2HSV)

        # Яскраво-червоний текст: висока насиченість, висока яскравість
        # (не темно-бордовий фон карток, а саме яскравий червоний текст)
        lower_red1 = np.array([0,   150, 150])
        upper_red1 = np.array([8,   255, 255])
        lower_red2 = np.array([170, 150, 150])
        upper_red2 = np.array([180, 255, 255])

        mask = cv2.bitwise_or(
            cv2.inRange(hsv, lower_red1, upper_red1),
            cv2.inRange(hsv, lower_red2, upper_red2)
        )
        mask = cv2.medianBlur(mask, 3)

        red_pixels   = np.count_nonzero(mask)
        total_pixels = btn_roi.shape[0] * btn_roi.shape[1]
        red_ratio    = red_pixels / total_pixels if total_pixels > 0 else 0.0

        # Поріг 0.02 = ~2% червоних пікселів достатньо щоб визначити текст таймера
        if red_ratio > 0.02:
            return True

        # --- Метод 2: шаблони як резервний варіант ---
        scales = [0.8, 0.9, 1.0, 1.1, 1.2]
        for tpl_name in ("red_timer.png", "join_timer.png"):
            tpl_path = os.path.join(self.templates_path, tpl_name)
            if not os.path.exists(tpl_path):
                continue
            best_val, _, _ = self.find_template_scaled(btn_roi, tpl_path, scales=scales)
            if best_val >= min_score:
                return True

        return False
