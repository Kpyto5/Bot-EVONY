import os
import zipfile
import subprocess
from datetime import datetime

def create_backup_and_open(source_dir=None):
    # Якщо не передано, беремо теку на рівень вище (корінь проєкту)
    if source_dir is None:
        source_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    backup_folder = os.path.join(source_dir, "backups")
    if not os.path.exists(backup_folder):
        os.makedirs(backup_folder)
    
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_filename = f"bot_backup_{timestamp}.zip"
    backup_path = os.path.join(backup_folder, backup_filename)
    
    # Список виключених папок (додайте свої)
    exclude = {'.git', '__pycache__', 'venv', '.idea', '.vscode', 'backups', 'logs', 'templates'}
    
    try:
        print("--- Початок створення бекапу... ---")
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                dirs[:] = [d for d in dirs if d not in exclude]
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, source_dir)
                    zipf.write(file_path, arcname)
        print(f"✅ Успішно: {backup_filename}")
        full_backup_dir = os.path.abspath(backup_folder)
        subprocess.run(['explorer', full_backup_dir])
    except Exception as e:
        print(f"❌ Помилка: {e}")

if __name__ == "__main__":
    create_backup_and_open()